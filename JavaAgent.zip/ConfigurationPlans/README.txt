Configuration plans are per-application XML files that specify individual application
monitoring requirements.  This will eventually supplant the pmonitor.config.xml 
configuration file; however, at present they are expected to work in parallel with 
the existing settings.

These configuration files users to specify custom JMX metrics to monitor. Like the example
XML below:

    <PerformanceCounterConfiguration 
      objectName="Catalina:context=/BeanSpy,host=localhost,type=Manager"
      property="activeSessions"
      calculateDelta="false"
      displayCategory="Sessions"
      displayName="Active Sessions" /> 

 Each MBean counter needs to be identified by a MBean ObjectName (wildcard characters not 
 allowed) and a property from the MBean.  Presently, only simple properties are supported.
 
 Since some counters always trend up (i.e. counters), for some metrics it will be more useful
 to find difference (or delta) between the current counter and the previous value of the
 counter.  For these types of counters, set the calculateDelta attribute to true.
 
 Finally, each returned counter should contain a category and name to appear in the UI. 